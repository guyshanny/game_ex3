#include "Sphere.h"


Sphere::Sphere(glm::vec3 c, double r) : _center(c), _radius(r) { }


